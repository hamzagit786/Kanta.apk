import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Calendar, 
  Truck, 
  Scale, 
  CheckCircle2, 
  AlertTriangle, 
  Lock,
  AlertCircle
} from 'lucide-react';
import { Driver, VehicleCategory } from '../types';
import { useKantaData } from '../context/KantaDataContext';
import { getTodayDateString } from '../lib/formatters';

interface AddDriverEntryFormProps {
  driver: Driver;
  onBack: () => void;
  onSaved: () => void;
}

const VEHICLE_CATEGORIES: VehicleCategory[] = [
  'Loader Rickshaw',
  'Milk Van',
  'Truck',
  'Other',
];

export const AddDriverEntryForm: React.FC<AddDriverEntryFormProps> = ({
  driver,
  onBack,
  onSaved,
}) => {
  const { addDriverEntry } = useKantaData();

  // Fields
  const [date, setDate] = useState<string>(getTodayDateString());
  const [vehicleCategory, setVehicleCategory] = useState<VehicleCategory>(
    driver.vehicleCategory || 'Loader Rickshaw'
  );
  const [vehicleReg, setVehicleReg] = useState<string>(driver.vehicleReg || '');
  const [firstWeight, setFirstWeight] = useState<string>('');
  const [secondWeight, setSecondWeight] = useState<string>('');
  const [thirdWeight, setThirdWeight] = useState<string>('');
  const [totalPrice, setTotalPrice] = useState<string>('');
  const [receivedPrice, setReceivedPrice] = useState<string>('0');
  const [confirmAdvance, setConfirmAdvance] = useState<boolean>(false);

  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Calculate automatically: Due Price = Total Price - Received Price
  const numTotal = Number(totalPrice) || 0;
  const numReceived = Number(receivedPrice) || 0;
  const rawDue = numTotal - numReceived;
  const duePrice = rawDue < 0 ? 0 : rawDue;
  const isAdvance = numReceived > numTotal && numTotal > 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (numTotal < 0) {
      setError('Total Price cannot be negative.');
      return;
    }
    if (numReceived < 0) {
      setError('Received Price cannot be negative.');
      return;
    }

    if (isAdvance && !confirmAdvance) {
      setError(
        `Received amount (Rs. ${numReceived}) is higher than Total Price (Rs. ${numTotal}). Please confirm advance payment below before saving.`
      );
      return;
    }

    setIsSubmitting(true);
    try {
      await addDriverEntry(driver.id, {
        date,
        vehicleCategory,
        vehicleReg: vehicleReg.trim() || undefined,
        firstWeight: firstWeight !== '' ? Number(firstWeight) : '',
        secondWeight: secondWeight !== '' ? Number(secondWeight) : '',
        thirdWeight: thirdWeight !== '' ? Number(thirdWeight) : '',
        totalPrice: numTotal,
        receivedPrice: numReceived,
        duePrice,
      });

      // After saving, return to driver's khata page
      onSaved();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save entry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-4 max-w-2xl mx-auto">
      {/* Top Breadcrumb Header */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-700 hover:text-blue-700 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to {driver.name}'s Khata</span>
        </button>
        <span className="text-xs bg-blue-50 text-blue-800 font-bold px-2.5 py-1 rounded-md">
          New Vehicle Weight Entry
        </span>
      </div>

      {/* Main Form Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-blue-700 text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Scale className="w-5 h-5 text-blue-200" />
            <h2 className="font-bold text-base sm:text-lg">
              Add Entry for {driver.name}
            </h2>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl flex items-center gap-2 text-xs font-semibold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Fixed Driver Name (User must not accidentally change it) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>Driver Name (Fixed)</span>
            </label>
            <div className="w-full text-sm font-black bg-slate-100 border border-slate-300 rounded-xl px-3.5 py-2.5 text-slate-800 select-none">
              {driver.name}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              This entry is strictly locked to {driver.name}'s independent khata account.
            </p>
          </div>

          {/* Date */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-blue-700" />
              <span>Date <span className="text-rose-500">*</span></span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Vehicle Category & Registration Number */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-blue-700" />
                <span>Vehicle Category <span className="text-rose-500">*</span></span>
              </label>
              <select
                required
                value={vehicleCategory}
                onChange={(e) => setVehicleCategory(e.target.value as VehicleCategory)}
                className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none bg-white"
              >
                {VEHICLE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Vehicle Registration # (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. LES-4412, GT-789"
                value={vehicleReg}
                onChange={(e) => setVehicleReg(e.target.value.toUpperCase())}
                className="w-full text-sm font-mono font-bold uppercase border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Manually Entered Weights: First, Second, Third */}
          <div>
            <span className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Vehicle Weights (Manual Values)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  First Weight
                </label>
                <input
                  type="number"
                  step="any"
                  placeholder="e.g. 14250"
                  value={firstWeight}
                  onChange={(e) => setFirstWeight(e.target.value)}
                  className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3 py-2.5 text-center focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Second Weight
                </label>
                <input
                  type="number"
                  step="any"
                  placeholder="e.g. 8100"
                  value={secondWeight}
                  onChange={(e) => setSecondWeight(e.target.value)}
                  className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3 py-2.5 text-center focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Third Weight
                </label>
                <input
                  type="number"
                  step="any"
                  placeholder="e.g. 6150"
                  value={thirdWeight}
                  onChange={(e) => setThirdWeight(e.target.value)}
                  className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3 py-2.5 text-center focus:border-blue-600 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Pricing: Total, Received, Due */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Total Price (PKR) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-500">Rs.</span>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    required
                    placeholder="0"
                    value={totalPrice}
                    onChange={(e) => setTotalPrice(e.target.value)}
                    className="w-full text-sm font-black pl-9 pr-3 py-2.5 border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none bg-white text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-emerald-800 mb-1">
                  Received Price (PKR)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-emerald-700">Rs.</span>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    placeholder="0"
                    value={receivedPrice}
                    onChange={(e) => setReceivedPrice(e.target.value)}
                    className="w-full text-sm font-black pl-9 pr-3 py-2.5 border border-emerald-400 rounded-xl focus:border-emerald-600 focus:outline-none bg-white text-emerald-950"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-rose-700 mb-1">
                  Due Price (PKR)
                </label>
                <div className="w-full text-sm font-black px-3.5 py-2.5 border border-rose-300 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-between">
                  <span>Rs. {duePrice.toLocaleString('en-PK')}</span>
                  <span className="text-[10px] uppercase font-bold text-rose-600">
                    {duePrice > 0 ? 'Baqi' : 'Clear'}
                  </span>
                </div>
              </div>
            </div>

            {isAdvance && (
              <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-900 space-y-1">
                <div className="flex items-center gap-1.5 font-bold">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span>Advance Payment Alert</span>
                </div>
                <p>
                  Received (Rs. {numReceived}) exceeds Total (Rs. {numTotal}) by Rs. {(numReceived - numTotal).toLocaleString('en-PK')}.
                </p>
                <label className="flex items-center gap-2 cursor-pointer font-bold pt-1">
                  <input
                    type="checkbox"
                    checked={confirmAdvance}
                    onChange={(e) => setConfirmAdvance(e.target.checked)}
                    className="rounded text-blue-600 w-4 h-4"
                  />
                  <span>Confirm Advance Payment</span>
                </label>
              </div>
            )}
          </div>

          {/* Large Save Entry Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-blue-700 hover:bg-blue-800 active:bg-blue-900 disabled:opacity-60 text-white font-black text-sm sm:text-base py-3.5 px-6 rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <span>Saving under {driver.name}...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Save Entry under {driver.name}'s Khata</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
