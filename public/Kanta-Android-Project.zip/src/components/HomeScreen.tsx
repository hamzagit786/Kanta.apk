import React, { useMemo } from 'react';
import { 
  Users, 
  UserCheck, 
  Receipt, 
  ChevronRight, 
  Scale, 
  ArrowUpRight, 
  Phone, 
  MapPin, 
  Building2,
  Wallet,
  AlertCircle,
  HandCoins,
  Smartphone,
  Download
} from 'lucide-react';
import { useKantaData } from '../context/KantaDataContext';
import { useAuth } from '../context/AuthContext';
import { formatPKR } from '../lib/formatters';

interface HomeScreenProps {
  onNavigateToDrivers: () => void;
  onNavigateToPersonal: () => void;
  onNavigateToExpenses: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigateToDrivers,
  onNavigateToPersonal,
  onNavigateToExpenses,
}) => {
  const { shopName, ownerName } = useAuth();
  const { drivers, entries, personalData, expenses, personalPeople, getPersonBalances } = useKantaData();

  // Summary stats for the quick top strip
  const totalDueAcrossDrivers = useMemo(() => {
    return entries.reduce((sum, e) => sum + e.duePrice, 0);
  }, [entries]);

  const totalOtherExpenses = useMemo(() => {
    return expenses.reduce((sum, e) => sum + e.amount, 0);
  }, [expenses]);

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-br from-blue-700 to-blue-900 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-800/80 border border-blue-500/40 text-blue-200 text-xs font-semibold">
            <Scale className="w-3.5 h-3.5 text-blue-300" />
            <span>{personalData.notes || '100-Ton Computerized Scale'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            {shopName || personalData.kantaName || 'Usman Computerized Kanta'}
          </h2>
          <p className="text-xs sm:text-sm text-blue-100 max-w-md">
            Owner: <strong>{ownerName || personalData.ownerName}</strong> {personalData.phone ? `• ${personalData.phone}` : ''}
          </p>
        </div>

        {/* Quick 2-stat bottom bar */}
        <div className="mt-5 pt-4 border-t border-blue-600/40 grid grid-cols-2 gap-3 relative z-10 text-xs">
          <div>
            <span className="text-blue-200 text-[11px] block font-medium">Total Drivers Outstanding</span>
            <span className="text-lg font-black text-rose-300">
              {formatPKR(totalDueAcrossDrivers)}
            </span>
          </div>
          <div>
            <span className="text-blue-200 text-[11px] block font-medium">Other Expenses</span>
            <span className="text-lg font-black text-white">
              {formatPKR(totalOtherExpenses)}
            </span>
          </div>
        </div>

        {/* Decorative background shape */}
        <div className="absolute -right-8 -bottom-8 w-44 h-44 bg-blue-600/20 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* The EXACT THREE Main Options */}
      <div className="space-y-3.5">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 px-1">
          Select an Option (ایک آپشن منتخب کریں)
        </h3>

        {/* 1. Drivers */}
        <button
          onClick={onNavigateToDrivers}
          className="w-full text-left bg-white hover:bg-blue-50/60 active:bg-blue-100/50 border-2 border-slate-200 hover:border-blue-500 rounded-2xl p-5 shadow-sm transition-all duration-200 cursor-pointer group flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <div className="w-13 h-13 rounded-2xl bg-blue-700 text-white flex items-center justify-center shrink-0 shadow-md group-hover:scale-105 transition-transform">
              <Users className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-black text-slate-900 group-hover:text-blue-700 transition-colors">
                  1. Drivers
                </span>
                <span className="text-xs font-bold bg-blue-100 text-blue-800 px-2.5 py-0.5 rounded-full">
                  {drivers.length} Driver{drivers.length === 1 ? '' : 's'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Manage independent driver accounts, view vehicle weight records, and track due balances.
              </p>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-100 group-hover:bg-blue-700 group-hover:text-white text-slate-600 flex items-center justify-center shrink-0 transition-colors">
            <ChevronRight className="w-5 h-5" />
          </div>
        </button>

        {/* 2. Personal Data */}
        <button
          onClick={onNavigateToPersonal}
          className="w-full text-left bg-white hover:bg-blue-50/60 active:bg-blue-100/50 border-2 border-slate-200 hover:border-blue-500 rounded-2xl p-5 shadow-sm transition-all duration-200 cursor-pointer group flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <div className="w-13 h-13 rounded-2xl bg-slate-800 text-white flex items-center justify-center shrink-0 shadow-md group-hover:scale-105 transition-transform">
              <HandCoins className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-black text-slate-900 group-hover:text-blue-700 transition-colors">
                  2. Personal Data
                </span>
                <span className="text-xs font-bold bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full">
                  {personalPeople.length} {personalPeople.length === 1 ? 'Person' : 'People'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Loan & Udhar accounts for money borrowed and lent, repayments, and balance tracking.
              </p>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-100 group-hover:bg-blue-700 group-hover:text-white text-slate-600 flex items-center justify-center shrink-0 transition-colors">
            <ChevronRight className="w-5 h-5" />
          </div>
        </button>

        {/* 3. Other Expenses */}
        <button
          onClick={onNavigateToExpenses}
          className="w-full text-left bg-white hover:bg-rose-50/60 active:bg-rose-100/50 border-2 border-slate-200 hover:border-rose-400 rounded-2xl p-5 shadow-sm transition-all duration-200 cursor-pointer group flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <div className="w-13 h-13 rounded-2xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-md group-hover:scale-105 transition-transform">
              <Receipt className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-black text-slate-900 group-hover:text-rose-700 transition-colors">
                  3. Other Expenses
                </span>
                <span className="text-xs font-bold bg-rose-100 text-rose-800 px-2.5 py-0.5 rounded-full">
                  {expenses.length} Records
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Record and monitor shop & scale operational expenses: electricity, computer repairs, tea, and rent.
              </p>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-100 group-hover:bg-rose-600 group-hover:text-white text-slate-600 flex items-center justify-center shrink-0 transition-colors">
            <ChevronRight className="w-5 h-5" />
          </div>
        </button>

        {/* Android App & APK Build Project Banner */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 text-white rounded-2xl p-5 shadow-md border border-blue-700/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mt-2">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-blue-600/60 border border-blue-400/40 flex items-center justify-center shrink-0 shadow-inner">
              <Smartphone className="w-6 h-6 text-blue-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm sm:text-base text-white">
                  Kanta Android App (APK)
                </span>
                <span className="text-[10px] bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 font-bold px-2 py-0.5 rounded-full">
                  Compiled & Ready (4.4 MB)
                </span>
              </div>
              <p className="text-xs text-blue-200 mt-0.5">
                Installable debug APK package (com.kanta.app) for Android phones and tablets.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <a
              href="/Kanta.apk"
              download="Kanta.apk"
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Kanta.apk</span>
            </a>
            <a
              href="/Kanta-Android-Project.zip"
              download="Kanta-Android-Project.zip"
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 bg-blue-800/80 hover:bg-blue-700 active:bg-blue-900 text-blue-100 text-xs font-semibold rounded-xl border border-blue-600/60 transition cursor-pointer"
              title="Download source code ZIP"
            >
              <span>Source ZIP</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
