import React, { useState, useEffect } from 'react';
import { 
  X, 
  Calendar, 
  Receipt, 
  CheckCircle2, 
  AlertTriangle, 
  User, 
  Plus, 
  CreditCard,
  Building2
} from 'lucide-react';
import { ExpenseCreditor, ExpensePaymentStatus } from '../../types';
import { useKantaData } from '../../context/KantaDataContext';
import { formatPKR, getTodayDateString } from '../../lib/formatters';

interface AddExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const EXPENSE_CATEGORIES = [
  'Electricity Bill',
  'Computer Repair',
  'Printer Paper & Ink',
  'Tea / Kharcha',
  'Rent',
  'Scale Maintenance',
  'Generator Fuel',
  'Shop Hardware',
  'Stationery',
  'Other',
];

const PAYMENT_METHODS = [
  'Cash',
  'Bank Transfer',
  'EasyPaisa',
  'JazzCash',
];

export const AddExpenseModal: React.FC<AddExpenseModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { expenses, expenseCreditors, addExpense, addExpenseCreditor } = useKantaData();

  const [date, setDate] = useState(getTodayDateString());
  const [category, setCategory] = useState(EXPENSE_CATEGORIES[0]);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<ExpensePaymentStatus>('cash');
  const [paymentMethod, setPaymentMethod] = useState(PAYMENT_METHODS[0]);

  // Credit fields
  const [creditorId, setCreditorId] = useState('');
  const [isAddingNewCreditor, setIsAddingNewCreditor] = useState(false);
  const [newCreditorName, setNewCreditorName] = useState('');
  const [newCreditorPhone, setNewCreditorPhone] = useState('');
  const [initialPaid, setInitialPaid] = useState('0');

  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setDate(getTodayDateString());
      setCategory(EXPENSE_CATEGORIES[0]);
      setDescription('');
      setAmount('');
      setPaymentStatus('cash');
      setPaymentMethod(PAYMENT_METHODS[0]);
      setCreditorId(expenseCreditors[0]?.id || '');
      setIsAddingNewCreditor(false);
      setNewCreditorName('');
      setNewCreditorPhone('');
      setInitialPaid('0');
      setError(null);
    }
  }, [isOpen, expenseCreditors]);

  if (!isOpen) return null;

  const numAmount = Number(amount) || 0;
  const numPaid = paymentStatus === 'credit' ? Number(initialPaid) || 0 : numAmount;
  const numDue = Math.max(0, numAmount - numPaid);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!numAmount || numAmount <= 0) {
      setError('Please enter a valid expense amount greater than 0.');
      return;
    }

    let finalCreditorId = creditorId;
    let finalCreditorName = '';

    if (paymentStatus === 'credit') {
      if (isAddingNewCreditor || expenseCreditors.length === 0) {
        if (!newCreditorName.trim()) {
          setError('Please enter the creditor person name (Credit Taken From).');
          return;
        }
      } else {
        if (!creditorId) {
          setError('Please select an existing creditor or add a new person.');
          return;
        }
      }

      if (numPaid > numAmount) {
        setError('Amount paid cannot exceed total expense amount.');
        return;
      }
    }

    setIsSubmitting(true);
    try {
      if (paymentStatus === 'credit') {
        if (isAddingNewCreditor || expenseCreditors.length === 0) {
          const createdCreditor = await addExpenseCreditor({
            name: newCreditorName.trim(),
            phone: newCreditorPhone.trim() || undefined,
          });
          finalCreditorId = createdCreditor.id;
          finalCreditorName = createdCreditor.name;
        } else {
          const found = expenseCreditors.find((c) => c.id === creditorId);
          finalCreditorName = found ? found.name : '';
        }
      }

      await addExpense({
        date,
        category,
        description: description.trim() || undefined,
        amount: numAmount,
        paymentStatus,
        creditorId: paymentStatus === 'credit' ? finalCreditorId : undefined,
        creditorName: paymentStatus === 'credit' ? finalCreditorName : undefined,
        initialPaid: paymentStatus === 'credit' ? numPaid : undefined,
        paymentMethod: paymentStatus === 'cash' ? paymentMethod : undefined,
      });

      onSuccess();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save expense.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-blue-700 text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Receipt className="w-5 h-5 text-blue-200" />
            <div>
              <h3 className="font-bold text-base sm:text-lg">Add Other Expense</h3>
              <p className="text-[11px] text-blue-200">Record cash or credit business expenses</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-blue-200 hover:text-white hover:bg-blue-600 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs sm:text-sm">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl flex items-center gap-2 text-xs font-semibold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Payment Status: Cash Paid OR Bought on Credit (Udhar) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Payment Status <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setPaymentStatus('cash')}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm border-2 transition cursor-pointer flex items-center justify-center gap-2 ${
                  paymentStatus === 'cash'
                    ? 'bg-emerald-50 border-emerald-600 text-emerald-950 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                  paymentStatus === 'cash' ? 'border-emerald-600 bg-emerald-600' : 'border-slate-300'
                }`}>
                  {paymentStatus === 'cash' && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                </div>
                <span>Cash Paid (نقد ادا)</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentStatus('credit')}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm border-2 transition cursor-pointer flex items-center justify-center gap-2 ${
                  paymentStatus === 'credit'
                    ? 'bg-amber-50 border-amber-600 text-amber-950 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                  paymentStatus === 'credit' ? 'border-amber-600 bg-amber-600' : 'border-slate-300'
                }`}>
                  {paymentStatus === 'credit' && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                </div>
                <span>Bought on Credit (ادھار خریدا)</span>
              </button>
            </div>
          </div>

          {/* Expense Date & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-blue-700" />
                <span>Expense Date <span className="text-rose-500">*</span></span>
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Category <span className="text-rose-500">*</span>
              </label>
              <select
                required
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none bg-white"
              >
                {EXPENSE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Description (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Printer ink ribbon for weighbridge, 20L generator diesel"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full text-sm border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Total Expense Amount */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Total Expense Amount (PKR) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-500">Rs.</span>
              <input
                type="number"
                min="1"
                step="1"
                required
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full text-sm font-black pl-10 pr-3.5 py-2.5 border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          {/* If Cash Paid: Payment Method */}
          {paymentStatus === 'cash' && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-blue-700" />
                <span>Payment Method</span>
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none bg-white"
              >
                {PAYMENT_METHODS.map((pm) => (
                  <option key={pm} value={pm}>
                    {pm}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* If Bought on Credit (Udhar): Creditor Name + Amount Paid + Outstanding Due */}
          {paymentStatus === 'credit' && (
            <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-200 space-y-3.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-950 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-amber-700" />
                  <span>Credit Taken From (Person Name) <span className="text-rose-500">*</span></span>
                </span>
                {expenseCreditors.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setIsAddingNewCreditor(!isAddingNewCreditor)}
                    className="text-xs font-bold text-blue-700 hover:underline cursor-pointer"
                  >
                    {isAddingNewCreditor ? 'Select Existing Creditor' : '+ Add New Creditor'}
                  </button>
                )}
              </div>

              {/* Creditor Selection or New Creditor Inputs */}
              {!isAddingNewCreditor && expenseCreditors.length > 0 ? (
                <div>
                  <select
                    required
                    value={creditorId}
                    onChange={(e) => {
                      if (e.target.value === '__new__') {
                        setIsAddingNewCreditor(true);
                      } else {
                        setCreditorId(e.target.value);
                      }
                    }}
                    className="w-full text-sm font-bold border border-amber-300 rounded-xl px-3.5 py-2.5 bg-white focus:border-amber-600 focus:outline-none text-slate-800"
                  >
                    <option value="">-- Select Creditor Person --</option>
                    {expenseCreditors.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.phone ? `(${c.phone})` : ''}
                      </option>
                    ))}
                    <option value="__new__">+ Add New Creditor Person...</option>
                  </select>
                </div>
              ) : (
                <div className="space-y-2">
                  <input
                    type="text"
                    required
                    placeholder="Enter Creditor Person Name (e.g. Tariq Electric, Bashir Diesel)"
                    value={newCreditorName}
                    onChange={(e) => setNewCreditorName(e.target.value)}
                    className="w-full text-sm font-bold border border-amber-300 rounded-xl px-3.5 py-2.5 bg-white focus:border-amber-600 focus:outline-none"
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number (Optional)"
                    value={newCreditorPhone}
                    onChange={(e) => setNewCreditorPhone(e.target.value)}
                    className="w-full text-xs border border-amber-300 rounded-xl px-3.5 py-2 bg-white focus:border-amber-600 focus:outline-none"
                  />
                </div>
              )}

              {/* Amount Paid So Far & Outstanding Due Calculation */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Amount Paid So Far
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2 text-xs font-bold text-slate-400">Rs.</span>
                    <input
                      type="number"
                      min="0"
                      max={numAmount}
                      value={initialPaid}
                      onChange={(e) => setInitialPaid(e.target.value)}
                      className="w-full text-sm font-black pl-8 pr-3 py-2 border border-slate-300 rounded-xl bg-white text-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-rose-700 mb-1">
                    Outstanding Expense Due
                  </label>
                  <div className="w-full text-sm font-black px-3 py-2 rounded-xl bg-rose-50 border border-rose-300 text-rose-700 flex items-center justify-between">
                    <span>Rs. {numDue.toLocaleString('en-PK')}</span>
                    <span className="text-[10px] font-bold uppercase text-rose-600">
                      {numDue > 0 ? 'Due' : 'Cleared'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Submit */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 border border-slate-300 rounded-xl text-slate-700 font-semibold hover:bg-slate-50 cursor-pointer text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white rounded-xl font-bold cursor-pointer transition flex items-center gap-1.5 text-xs shadow-md"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving...' : 'Save Expense'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
