import React, { useState, useEffect } from 'react';
import { 
  X, 
  Calendar, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { ExpenseCreditor, OtherExpense } from '../../types';
import { useKantaData } from '../../context/KantaDataContext';
import { formatPKR, getTodayDateString, formatDate } from '../../lib/formatters';

interface RecordExpensePaymentModalProps {
  creditor: ExpenseCreditor;
  preselectedExpenseId?: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const RecordExpensePaymentModal: React.FC<RecordExpensePaymentModalProps> = ({
  creditor,
  preselectedExpenseId,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { getCreditorExpenses, addExpensePayment } = useKantaData();

  const creditorExpenses = getCreditorExpenses(creditor.id);
  const pendingExpenses = creditorExpenses.filter((e) => (e.dueAmount || 0) > 0);

  const [expenseId, setExpenseId] = useState(preselectedExpenseId || '');
  const [date, setDate] = useState(getTodayDateString());
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setDate(getTodayDateString());
      setAmount('');
      setNotes('');
      setError(null);
      if (preselectedExpenseId) {
        setExpenseId(preselectedExpenseId);
      } else {
        setExpenseId(pendingExpenses[0]?.id || creditorExpenses[0]?.id || '');
      }
    }
  }, [isOpen, preselectedExpenseId]);

  if (!isOpen) return null;

  const currentExpense = creditorExpenses.find((e) => e.id === expenseId);
  const remainingDue = currentExpense ? (currentExpense.dueAmount ?? currentExpense.amount) : 0;
  const numAmount = Number(amount) || 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!expenseId) {
      setError('Please select an expense entry to pay.');
      return;
    }
    if (!numAmount || numAmount <= 0) {
      setError('Please enter a valid payment amount greater than 0.');
      return;
    }
    if (numAmount > remainingDue) {
      setError(`Payment amount (${formatPKR(numAmount)}) cannot exceed outstanding due (${formatPKR(remainingDue)}).`);
      return;
    }

    setIsSubmitting(true);
    try {
      await addExpensePayment({
        expenseId,
        creditorId: creditor.id,
        date,
        amount: numAmount,
        notes: notes.trim() || undefined,
      });

      onSuccess();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to record payment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        <div className="bg-blue-700 text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <RotateCcw className="w-5 h-5 text-blue-200" />
            <div>
              <h3 className="font-bold text-base sm:text-lg">Record Payment to Creditor</h3>
              <p className="text-[11px] text-blue-200">Creditor: {creditor.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-blue-200 hover:text-white hover:bg-blue-600 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs sm:text-sm">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl flex items-center gap-2 text-xs font-semibold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Select Credit Expense */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Select Credit Expense <span className="text-rose-500">*</span>
            </label>
            {creditorExpenses.length === 0 ? (
              <div className="p-3 bg-slate-100 rounded-xl text-center text-xs text-slate-500">
                No credit expenses recorded under {creditor.name}.
              </div>
            ) : (
              <select
                required
                value={expenseId}
                onChange={(e) => setExpenseId(e.target.value)}
                className="w-full text-xs sm:text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none bg-white"
              >
                <option value="">-- Choose Credit Expense --</option>
                {creditorExpenses.map((exp) => (
                  <option key={exp.id} value={exp.id}>
                    {formatDate(exp.date)}: {exp.category} — Total: {formatPKR(exp.amount)} | Due: {formatPKR(exp.dueAmount ?? exp.amount)}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Display Details of Selected Expense */}
          {currentExpense && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-500 block">
                  Remaining Due on this Bill
                </span>
                <span className="text-base font-black text-rose-700">
                  {formatPKR(remainingDue)}
                </span>
                <span className="text-[11px] text-slate-400 block">
                  Total Bill: {formatPKR(currentExpense.amount)}
                </span>
              </div>

              {remainingDue > 0 && (
                <button
                  type="button"
                  onClick={() => setAmount(String(remainingDue))}
                  className="px-2.5 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-800 text-[11px] font-bold rounded-lg cursor-pointer transition"
                >
                  Pay Full ({formatPKR(remainingDue)})
                </button>
              )}
            </div>
          )}

          {/* Payment Date */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-blue-700" />
              <span>Payment Date <span className="text-rose-500">*</span></span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Payment Amount */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Payment Amount (PKR) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-500">Rs.</span>
              <input
                type="number"
                min="1"
                max={remainingDue}
                step="1"
                required
                autoFocus
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full text-sm font-black pl-10 pr-3.5 py-2.5 border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Notes (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Paid via cash, partial installment"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-sm border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 border border-slate-300 rounded-xl text-slate-700 font-semibold hover:bg-slate-50 cursor-pointer text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || creditorExpenses.length === 0}
              className="px-5 py-2.5 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white rounded-xl font-bold cursor-pointer transition flex items-center gap-1.5 text-xs shadow-md"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Recording...' : 'Record Payment'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
