import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Calendar, 
  DollarSign, 
  CheckCircle2, 
  AlertTriangle, 
  Lock, 
  RotateCcw, 
  ArrowUpRight, 
  ArrowDownLeft,
  AlertCircle
} from 'lucide-react';
import { PersonalPerson, RepaymentDirection } from '../../types';
import { useKantaData } from '../../context/KantaDataContext';
import { formatPKR, getTodayDateString, formatDate } from '../../lib/formatters';

interface RecordRepaymentModalProps {
  person: PersonalPerson;
  preselectedLoanId?: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const RecordRepaymentModal: React.FC<RecordRepaymentModalProps> = ({
  person,
  preselectedLoanId,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { getPersonLoans, getLoanRemaining, addPersonalRepayment } = useKantaData();

  const personLoans = useMemo(() => {
    return getPersonLoans(person.id);
  }, [getPersonLoans, person.id]);

  // Determine initial direction
  const preselectedLoan = personLoans.find((l) => l.id === preselectedLoanId);
  const initialDirection: RepaymentDirection = preselectedLoan?.type === 'lent'
    ? 'received_lent'
    : 'repaid_borrowed';

  const [direction, setDirection] = useState<RepaymentDirection>(initialDirection);
  const [selectedLoanId, setSelectedLoanId] = useState<string>('');
  const [date, setDate] = useState(getTodayDateString());
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [confirmExcess, setConfirmExcess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filter loans by active direction
  // direction 'repaid_borrowed' matches loans with type === 'borrowed'
  // direction 'received_lent' matches loans with type === 'lent'
  const matchingLoans = useMemo(() => {
    const targetType = direction === 'repaid_borrowed' ? 'borrowed' : 'lent';
    return personLoans.filter((l) => l.type === targetType);
  }, [personLoans, direction]);

  useEffect(() => {
    if (isOpen) {
      setDate(getTodayDateString());
      setAmount('');
      setNotes('');
      setError(null);
      setConfirmExcess(false);

      if (preselectedLoanId && preselectedLoan) {
        setDirection(preselectedLoan.type === 'lent' ? 'received_lent' : 'repaid_borrowed');
        setSelectedLoanId(preselectedLoanId);
      } else {
        // default select first loan with positive remaining balance or first matching loan
        const firstActive = matchingLoans.find((l) => getLoanRemaining(l.id) > 0) || matchingLoans[0];
        setSelectedLoanId(firstActive ? firstActive.id : '');
      }
    }
  }, [isOpen, preselectedLoanId]);

  // When direction changes, pick appropriate loan if current selection doesn't match
  const handleDirectionChange = (newDir: RepaymentDirection) => {
    setDirection(newDir);
    setConfirmExcess(false);
    const targetType = newDir === 'repaid_borrowed' ? 'borrowed' : 'lent';
    const available = personLoans.filter((l) => l.type === targetType);
    const firstActive = available.find((l) => getLoanRemaining(l.id) > 0) || available[0];
    setSelectedLoanId(firstActive ? firstActive.id : '');
  };

  if (!isOpen) return null;

  const currentLoan = personLoans.find((l) => l.id === selectedLoanId);
  const remainingOnCurrent = currentLoan ? getLoanRemaining(currentLoan.id) : 0;
  const numAmount = Number(amount) || 0;
  const isExcess = numAmount > remainingOnCurrent && remainingOnCurrent > 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedLoanId) {
      setError('Please select a loan transaction to repay against.');
      return;
    }
    if (!numAmount || numAmount <= 0) {
      setError('Please enter a valid repayment amount greater than 0.');
      return;
    }

    if (isExcess && !confirmExcess) {
      setError(
        `Repayment amount (${formatPKR(numAmount)}) exceeds the remaining loan balance (${formatPKR(remainingOnCurrent)}). Please confirm excess payment below before proceeding.`
      );
      return;
    }

    setIsSubmitting(true);
    try {
      await addPersonalRepayment({
        personId: person.id,
        loanId: selectedLoanId,
        date,
        direction,
        amount: numAmount,
        notes: notes.trim() || undefined,
      });

      onSuccess();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save repayment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isRepayingBorrowed = direction === 'repaid_borrowed';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-blue-700 text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-800 flex items-center justify-center">
              <RotateCcw className="w-5 h-5 text-blue-200" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">Record Repayment (ادائیگی / واپسی)</h3>
              <p className="text-[11px] text-blue-200">Account: {person.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-blue-200 hover:text-white hover:bg-blue-600 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs sm:text-sm">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl flex items-center gap-2 text-xs font-semibold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Direction Selector: Repaid Money I Borrowed OR Received Money I Lent */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Select Repayment Direction <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleDirectionChange('repaid_borrowed')}
                className={`p-3 rounded-xl font-bold text-xs border-2 text-left transition cursor-pointer flex items-start gap-2.5 ${
                  isRepayingBorrowed
                    ? 'bg-amber-50 border-amber-600 text-amber-950 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <ArrowUpRight className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Repaid Money I Borrowed</div>
                  <div className="text-[10px] font-normal text-slate-500 mt-0.5">
                    I am returning money to {person.name}
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleDirectionChange('received_lent')}
                className={`p-3 rounded-xl font-bold text-xs border-2 text-left transition cursor-pointer flex items-start gap-2.5 ${
                  !isRepayingBorrowed
                    ? 'bg-emerald-50 border-emerald-600 text-emerald-950 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <ArrowDownLeft className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Received Money I Lent</div>
                  <div className="text-[10px] font-normal text-slate-500 mt-0.5">
                    {person.name} returned money to me
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Select Relevant Loan Transaction */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center justify-between">
              <span>Select Loan Transaction <span className="text-rose-500">*</span></span>
              <span className="text-[11px] font-normal text-slate-400 lowercase">
                {matchingLoans.length} available
              </span>
            </label>

            {matchingLoans.length === 0 ? (
              <div className="p-3.5 bg-slate-100 rounded-xl text-center text-xs text-slate-500 font-medium">
                No {isRepayingBorrowed ? 'borrowed' : 'lent'} loans found for {person.name}. Please add a loan first.
              </div>
            ) : (
              <select
                required
                value={selectedLoanId}
                onChange={(e) => setSelectedLoanId(e.target.value)}
                className="w-full text-xs sm:text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none bg-white"
              >
                <option value="">-- Choose Loan to Repay --</option>
                {matchingLoans.map((l) => {
                  const rem = getLoanRemaining(l.id);
                  return (
                    <option key={l.id} value={l.id}>
                      {formatDate(l.date)} — Original: {formatPKR(l.amount)} | Remaining: {formatPKR(rem)} {l.notes ? `(${l.notes})` : ''}
                    </option>
                  );
                })}
              </select>
            )}
          </div>

          {/* Display Current Loan Details if selected */}
          {currentLoan && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                  Remaining on Selected Loan
                </span>
                <span className="text-base sm:text-lg font-black text-slate-900">
                  {formatPKR(remainingOnCurrent)}
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Original: {formatPKR(currentLoan.amount)} taken on {formatDate(currentLoan.date)}
                </span>
              </div>

              {remainingOnCurrent > 0 && (
                <button
                  type="button"
                  onClick={() => setAmount(String(remainingOnCurrent))}
                  className="px-2.5 py-1.5 bg-blue-100 hover:bg-blue-200 text-blue-800 text-[11px] font-bold rounded-lg cursor-pointer transition"
                >
                  Pay Full ({formatPKR(remainingOnCurrent)})
                </button>
              )}
            </div>
          )}

          {/* Repayment Date */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-blue-700" />
              <span>Repayment Date <span className="text-rose-500">*</span></span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Repayment Amount */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Repayment Amount (PKR) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-500">Rs.</span>
              <input
                type="number"
                min="1"
                step="1"
                required
                autoFocus
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full text-sm font-black pl-10 pr-3.5 py-2.5 border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Partial repayments and multiple installments are allowed against this loan.
            </p>
          </div>

          {/* Warning if amount exceeds remaining balance */}
          {isExcess && (
            <div className="p-3.5 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-950 space-y-2">
              <div className="flex items-center gap-1.5 font-bold">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Overpayment / Advance Warning</span>
              </div>
              <p>
                Repayment amount ({formatPKR(numAmount)}) is greater than remaining balance ({formatPKR(remainingOnCurrent)}) by {formatPKR(numAmount - remainingOnCurrent)}.
              </p>
              <label className="flex items-center gap-2 cursor-pointer font-bold pt-1">
                <input
                  type="checkbox"
                  checked={confirmExcess}
                  onChange={(e) => setConfirmExcess(e.target.checked)}
                  className="rounded text-blue-600 w-4 h-4"
                />
                <span>Confirm excess payment / advance</span>
              </label>
            </div>
          )}

          {/* Notes (Optional) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Notes (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Paid via cash, bank transfer, installment 1"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-sm border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Submit / Cancel */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 border border-slate-300 rounded-xl text-slate-700 font-semibold hover:bg-slate-50 cursor-pointer text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || matchingLoans.length === 0}
              className="px-5 py-2.5 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white rounded-xl font-bold cursor-pointer transition flex items-center gap-1.5 text-xs shadow-md"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Recording...' : 'Record Repayment'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
