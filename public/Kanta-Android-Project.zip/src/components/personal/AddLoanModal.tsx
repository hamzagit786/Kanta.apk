import React, { useState, useEffect } from 'react';
import { X, Calendar, DollarSign, CheckCircle2, AlertTriangle, Lock, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { PersonalPerson, LoanType } from '../../types';
import { useKantaData } from '../../context/KantaDataContext';
import { getTodayDateString } from '../../lib/formatters';

interface AddLoanModalProps {
  person: PersonalPerson;
  defaultType: LoanType;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AddLoanModal: React.FC<AddLoanModalProps> = ({
  person,
  defaultType,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { addPersonalLoan } = useKantaData();

  const [date, setDate] = useState(getTodayDateString());
  const [type, setType] = useState<LoanType>(defaultType);
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setType(defaultType);
      setDate(getTodayDateString());
      setAmount('');
      setNotes('');
      setError(null);
    }
  }, [isOpen, defaultType]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) {
      setError('Please enter a valid loan amount greater than 0.');
      return;
    }

    setIsSubmitting(true);
    try {
      await addPersonalLoan({
        personId: person.id,
        personName: person.name,
        date,
        type,
        amount: numAmount,
        notes: notes.trim() || undefined,
      });

      onSuccess();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save loan transaction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isBorrowed = type === 'borrowed';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header styling based on type */}
        <div className={`px-5 py-4 text-white flex items-center justify-between ${
          isBorrowed ? 'bg-amber-600' : 'bg-emerald-600'
        }`}>
          <div className="flex items-center gap-2.5">
            {isBorrowed ? (
              <div className="w-8 h-8 rounded-lg bg-amber-700 flex items-center justify-center">
                <ArrowDownLeft className="w-5 h-5 text-amber-200" />
              </div>
            ) : (
              <div className="w-8 h-8 rounded-lg bg-emerald-700 flex items-center justify-center">
                <ArrowUpRight className="w-5 h-5 text-emerald-200" />
              </div>
            )}
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                {isBorrowed ? '+ I Borrowed Money (میں نے ادھار لیا)' : '+ I Lent Money (میں نے ادھار دیا)'}
              </h3>
              <p className="text-[11px] text-white/80">Account: {person.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-black/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs sm:text-sm">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl flex items-center gap-2 text-xs font-semibold">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Fixed Person Name */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>Person Name (Fixed)</span>
            </label>
            <div className="w-full text-sm font-black bg-slate-100 border border-slate-300 rounded-xl px-3.5 py-2.5 text-slate-800 select-none">
              {person.name}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              This loan is strictly recorded inside {person.name}'s independent personal khata.
            </p>
          </div>

          {/* Transaction Type Selector (Preselected, allows changing) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Transaction Type <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setType('borrowed')}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs border-2 transition cursor-pointer flex items-center justify-center gap-2 ${
                  type === 'borrowed'
                    ? 'bg-amber-50 border-amber-600 text-amber-900 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <ArrowDownLeft className="w-4 h-4 text-amber-600" />
                <span>I Borrowed (لیا)</span>
              </button>

              <button
                type="button"
                onClick={() => setType('lent')}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs border-2 transition cursor-pointer flex items-center justify-center gap-2 ${
                  type === 'lent'
                    ? 'bg-emerald-50 border-emerald-600 text-emerald-900 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                <span>I Lent (دیا)</span>
              </button>
            </div>
          </div>

          {/* Transaction Date */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-blue-700" />
              <span>Transaction Date <span className="text-rose-500">*</span></span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full text-sm font-semibold border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Amount (PKR, Required) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Amount (PKR) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-500">Rs.</span>
              <input
                type="number"
                min="1"
                step="1"
                required
                autoFocus
                placeholder="e.g. 50000"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full text-sm font-black pl-10 pr-3.5 py-2.5 border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Notes (Optional) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Notes / Reason (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Loan for shop paint, scale sensor repair, temporary cash"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-sm border border-slate-300 rounded-xl px-3.5 py-2.5 focus:border-blue-600 focus:outline-none"
            />
          </div>

          {/* Action buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 border border-slate-300 rounded-xl text-slate-700 font-semibold hover:bg-slate-50 cursor-pointer text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-5 py-2.5 text-white rounded-xl font-bold cursor-pointer transition flex items-center gap-1.5 text-xs shadow-md ${
                isBorrowed
                  ? 'bg-amber-600 hover:bg-amber-700'
                  : 'bg-emerald-600 hover:bg-emerald-700'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>
                {isSubmitting ? 'Saving...' : `Save ${isBorrowed ? 'Borrowed' : 'Lent'} Loan`}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
