import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  updateProfile
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, testFirestoreConnection } from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  firestoreConnected: boolean;
  shopName: string;
  ownerName: string;
  needsProfileSetup: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, ownerName: string, shopName: string) => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  saveUserProfile: (ownerName: string, shopName: string) => Promise<void>;
  logout: () => Promise<void>;
  authError: string | null;
  clearAuthError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [firestoreConnected, setFirestoreConnected] = useState(false);
  const [shopName, setShopName] = useState<string>('Usman Computerized Kanta');
  const [ownerName, setOwnerName] = useState<string>('Usman');
  const [needsProfileSetup, setNeedsProfileSetup] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthError(null);

      if (currentUser) {
        const connected = await testFirestoreConnection();
        setFirestoreConnected(connected);

        // Fetch user profile from Firestore to get personalized Shop Name and Owner Name
        try {
          const profileRef = doc(db, 'users', currentUser.uid, 'personal_data', 'profile');
          const profileSnap = await getDoc(profileRef);

          if (profileSnap.exists()) {
            const data = profileSnap.data();
            const savedShop = data.shopName || data.kantaName || '';
            const savedOwner = data.ownerName || currentUser.displayName || '';

            if (savedShop.trim()) {
              setShopName(savedShop);
              setOwnerName(savedOwner);
              setNeedsProfileSetup(false);
            } else {
              // Shop Name is mandatory
              setNeedsProfileSetup(true);
              setOwnerName(savedOwner || 'Owner');
            }
          } else {
            // First time login with Google or empty profile: Prompt for Shop Name
            setNeedsProfileSetup(true);
            setOwnerName(currentUser.displayName || 'Owner');
          }
        } catch (err) {
          console.error('Error fetching user profile:', err);
          // Fallback to local storage if offline
          const localShop = localStorage.getItem(`shop_name_${currentUser.uid}`);
          const localOwner = localStorage.getItem(`owner_name_${currentUser.uid}`);
          if (localShop) {
            setShopName(localShop);
            setOwnerName(localOwner || 'Owner');
            setNeedsProfileSetup(false);
          } else {
            setNeedsProfileSetup(true);
          }
        }
      } else {
        setFirestoreConnected(false);
        setNeedsProfileSetup(false);
      }

      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const saveUserProfile = async (newOwnerName: string, newShopName: string) => {
    if (!user) return;
    const trimmedShop = newShopName.trim();
    const trimmedOwner = newOwnerName.trim();

    if (!trimmedShop) {
      throw new Error('Shop Name is mandatory.');
    }

    setShopName(trimmedShop);
    setOwnerName(trimmedOwner);
    setNeedsProfileSetup(false);

    localStorage.setItem(`shop_name_${user.uid}`, trimmedShop);
    localStorage.setItem(`owner_name_${user.uid}`, trimmedOwner);

    try {
      await updateProfile(user, {
        displayName: trimmedOwner,
      });
    } catch {
      // Ignore
    }

    try {
      const profileRef = doc(db, 'users', user.uid, 'personal_data', 'profile');
      await setDoc(profileRef, {
        ownerName: trimmedOwner,
        shopName: trimmedShop,
        kantaName: trimmedShop,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
    } catch (err) {
      console.error('Error saving profile to Firestore:', err);
    }
  };

  const signInWithGoogle = async () => {
    setAuthError(null);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      await signInWithPopup(auth, provider);
    } catch (err: unknown) {
      console.error('Google Sign In Error:', err);
      const msg = err instanceof Error ? err.message : 'Could not sign in with Google';
      setAuthError(msg);
      throw err;
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    setAuthError(null);
    try {
      await signInWithEmailAndPassword(auth, email.trim(), pass);
    } catch (err: unknown) {
      console.error('Email Sign In Error:', err);
      const msg = err instanceof Error ? err.message : 'Invalid email or password';
      setAuthError(msg);
      throw err;
    }
  };

  const registerWithEmail = async (
    email: string, 
    pass: string, 
    owner: string, 
    shop: string
  ) => {
    setAuthError(null);
    if (!shop.trim()) {
      throw new Error('Shop Name is mandatory.');
    }
    if (!owner.trim()) {
      throw new Error("Owner's Full Name is required.");
    }

    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
      const newUser = cred.user;

      try {
        await updateProfile(newUser, { displayName: owner.trim() });
      } catch {
        // Continue
      }

      try {
        await sendEmailVerification(newUser);
      } catch {
        // Verification email optional if provider restricts
      }

      // Save initial profile in Firestore
      const profileRef = doc(db, 'users', newUser.uid, 'personal_data', 'profile');
      await setDoc(profileRef, {
        ownerName: owner.trim(),
        shopName: shop.trim(),
        kantaName: shop.trim(),
        phone: '',
        address: '',
        notes: '',
        updatedAt: new Date().toISOString(),
      });

      setShopName(shop.trim());
      setOwnerName(owner.trim());
      setNeedsProfileSetup(false);
      localStorage.setItem(`shop_name_${newUser.uid}`, shop.trim());
      localStorage.setItem(`owner_name_${newUser.uid}`, owner.trim());
    } catch (err: unknown) {
      console.error('Registration Error:', err);
      const msg = err instanceof Error ? err.message : 'Failed to register account';
      setAuthError(msg);
      throw err;
    }
  };

  const sendPasswordReset = async (email: string) => {
    setAuthError(null);
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (err: unknown) {
      console.error('Password Reset Error:', err);
      const msg = err instanceof Error ? err.message : 'Failed to send password reset email';
      setAuthError(msg);
      throw err;
    }
  };

  const logout = async () => {
    setAuthError(null);
    try {
      await signOut(auth);
    } catch (err: unknown) {
      console.error('Sign Out Error:', err);
    }
  };

  const clearAuthError = () => setAuthError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        firestoreConnected,
        shopName,
        ownerName,
        needsProfileSetup,
        signInWithGoogle,
        signInWithEmail,
        registerWithEmail,
        sendPasswordReset,
        saveUserProfile,
        logout,
        authError,
        clearAuthError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
