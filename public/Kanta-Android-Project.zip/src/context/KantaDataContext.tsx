import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot 
} from 'firebase/firestore';
import { 
  Driver, 
  KantaEntry, 
  PersonalData, 
  OtherExpense, 
  VehicleCategory,
  PersonalPerson,
  PersonalLoan,
  PersonalRepayment,
  LoanType,
  RepaymentDirection,
  ExpenseCreditor,
  ExpensePayment,
  ExpensePaymentStatus
} from '../types';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from './AuthContext';

export interface PersonBalanceSummary {
  totalBorrowed: number;
  totalRepaidBorrowed: number;
  remainingBorrowed: number;
  totalLent: number;
  totalRepaidLent: number;
  remainingLent: number;
  netPosition: number;
}

export interface CreditorBalanceSummary {
  totalCredit: number;
  totalPaid: number;
  remainingDue: number;
}

interface KantaDataContextType {
  drivers: Driver[];
  entries: KantaEntry[];
  personalData: PersonalData;
  expenses: OtherExpense[];
  
  // Personal Data — Loan & Udhar
  personalPeople: PersonalPerson[];
  personalLoans: PersonalLoan[];
  personalRepayments: PersonalRepayment[];

  // Other Expenses — Creditors & Payments
  expenseCreditors: ExpenseCreditor[];
  expensePayments: ExpensePayment[];

  loading: boolean;
  
  // Driver methods
  addDriver: (data: {
    name: string;
    vehicleCategory?: VehicleCategory;
    vehicleReg?: string;
    phone?: string;
  }) => Promise<Driver>;
  updateDriver: (id: string, updates: Partial<Driver>) => Promise<void>;
  deleteDriver: (id: string) => Promise<void>;

  // Driver-specific entries methods
  getDriverEntries: (driverId: string) => KantaEntry[];
  addDriverEntry: (
    driverId: string,
    entry: {
      date: string;
      vehicleCategory: VehicleCategory;
      vehicleReg?: string;
      firstWeight: number | '';
      secondWeight: number | '';
      thirdWeight: number | '';
      totalPrice: number;
      receivedPrice: number;
      duePrice: number;
    }
  ) => Promise<KantaEntry>;
  updateEntry: (entryId: string, updates: Partial<KantaEntry>) => Promise<void>;
  deleteEntry: (entryId: string) => Promise<void>;

  // Personal Profile Data methods
  updatePersonalData: (data: Partial<PersonalData>) => Promise<void>;

  // Other Expenses methods (Cash or Credit)
  addExpense: (expense: {
    date: string;
    category: string;
    description?: string;
    amount: number;
    paymentStatus: ExpensePaymentStatus;
    creditorId?: string;
    creditorName?: string;
    initialPaid?: number;
    paymentMethod?: string;
  }) => Promise<OtherExpense>;
  deleteExpense: (id: string) => Promise<void>;

  // Expense Creditors methods
  addExpenseCreditor: (data: {
    name: string;
    phone?: string;
    notes?: string;
  }) => Promise<ExpenseCreditor>;
  updateExpenseCreditor: (id: string, updates: Partial<ExpenseCreditor>) => Promise<void>;
  deleteExpenseCreditor: (id: string) => Promise<void>;

  // Expense Payments methods
  addExpensePayment: (data: {
    expenseId: string;
    creditorId: string;
    date: string;
    amount: number;
    notes?: string;
  }) => Promise<ExpensePayment>;
  deleteExpensePayment: (id: string) => Promise<void>;

  // Selectors for Expense Creditors
  getCreditorExpenses: (creditorId: string) => OtherExpense[];
  getCreditorPayments: (creditorId: string) => ExpensePayment[];
  getExpensePayments: (expenseId: string) => ExpensePayment[];
  getCreditorBalances: (creditorId: string) => CreditorBalanceSummary;

  // Personal Loan & Udhar People methods
  addPersonalPerson: (data: {
    name: string;
    phone?: string;
    notes?: string;
  }) => Promise<PersonalPerson>;
  updatePersonalPerson: (id: string, updates: Partial<PersonalPerson>) => Promise<void>;
  deletePersonalPerson: (id: string) => Promise<void>;

  // Personal Loan Transactions methods
  addPersonalLoan: (data: {
    personId: string;
    personName: string;
    date: string;
    type: LoanType;
    amount: number;
    notes?: string;
  }) => Promise<PersonalLoan>;
  updatePersonalLoan: (id: string, updates: Partial<PersonalLoan>) => Promise<void>;
  deletePersonalLoan: (id: string) => Promise<void>;

  // Personal Repayments methods
  addPersonalRepayment: (data: {
    personId: string;
    loanId: string;
    date: string;
    direction: RepaymentDirection;
    amount: number;
    notes?: string;
  }) => Promise<PersonalRepayment>;
  deletePersonalRepayment: (id: string) => Promise<void>;

  // Calculations & Selectors for Personal Loan
  getPersonLoans: (personId: string) => PersonalLoan[];
  getPersonRepayments: (personId: string) => PersonalRepayment[];
  getLoanRepayments: (loanId: string) => PersonalRepayment[];
  getPersonBalances: (personId: string) => PersonBalanceSummary;
  getLoanRemaining: (loanId: string) => number;
}

const KantaDataContext = createContext<KantaDataContextType | undefined>(undefined);

const LS_DRIVERS = 'usman_kanta_drivers_v2';
const LS_ENTRIES = 'usman_kanta_entries_v2';
const LS_PERSONAL = 'usman_kanta_personal_v2';
const LS_EXPENSES = 'usman_kanta_expenses_v2';
const LS_PEOPLE = 'usman_kanta_personal_people_v1';
const LS_LOANS = 'usman_kanta_personal_loans_v1';
const LS_REPAYMENTS = 'usman_kanta_personal_repayments_v1';
const LS_CREDITORS = 'usman_kanta_creditors_v1';
const LS_EXP_PAYMENTS = 'usman_kanta_exp_payments_v1';

const defaultPersonalData: PersonalData = {
  ownerName: 'Usman',
  shopName: 'Usman Computerized Kanta',
  phone: '0300-1234567',
  kantaName: 'Usman Computerized Kanta',
  address: 'Main G.T. Road, Pakistan',
  notes: 'Govt. Approved 100-Ton Electronic Weighbridge',
  updatedAt: new Date().toISOString(),
};

export const KantaDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  const [drivers, setDrivers] = useState<Driver[]>(() => {
    try {
      const saved = localStorage.getItem(LS_DRIVERS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [entries, setEntries] = useState<KantaEntry[]>(() => {
    try {
      const saved = localStorage.getItem(LS_ENTRIES);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [personalData, setPersonalData] = useState<PersonalData>(() => {
    try {
      const saved = localStorage.getItem(LS_PERSONAL);
      return saved ? JSON.parse(saved) : defaultPersonalData;
    } catch {
      return defaultPersonalData;
    }
  });

  const [expenses, setExpenses] = useState<OtherExpense[]>(() => {
    try {
      const saved = localStorage.getItem(LS_EXPENSES);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Personal Loan & Udhar states
  const [personalPeople, setPersonalPeople] = useState<PersonalPerson[]>(() => {
    try {
      const saved = localStorage.getItem(LS_PEOPLE);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [personalLoans, setPersonalLoans] = useState<PersonalLoan[]>(() => {
    try {
      const saved = localStorage.getItem(LS_LOANS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [personalRepayments, setPersonalRepayments] = useState<PersonalRepayment[]>(() => {
    try {
      const saved = localStorage.getItem(LS_REPAYMENTS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Other Expenses — Creditors & Payments
  const [expenseCreditors, setExpenseCreditors] = useState<ExpenseCreditor[]>(() => {
    try {
      const saved = localStorage.getItem(LS_CREDITORS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [expensePayments, setExpensePayments] = useState<ExpensePayment[]>(() => {
    try {
      const saved = localStorage.getItem(LS_EXP_PAYMENTS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [loading, setLoading] = useState(true);

  // Sync with Firestore when user is authenticated
  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const userId = user.uid;

    // Listen to Drivers
    const unsubDrivers = onSnapshot(
      collection(db, 'users', userId, 'drivers'),
      (snapshot) => {
        const list: Driver[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as Driver);
        });
        list.sort((a, b) => a.name.localeCompare(b.name));
        setDrivers(list);
        localStorage.setItem(LS_DRIVERS, JSON.stringify(list));
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/drivers`);
      }
    );

    // Listen to Vehicle Weight Entries
    const unsubEntries = onSnapshot(
      collection(db, 'users', userId, 'kanta_entries'),
      (snapshot) => {
        const list: KantaEntry[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as KantaEntry);
        });
        setEntries(list);
        localStorage.setItem(LS_ENTRIES, JSON.stringify(list));
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/kanta_entries`);
        setLoading(false);
      }
    );

    // Listen to Personal Profile Data
    const unsubPersonal = onSnapshot(
      doc(db, 'users', userId, 'personal_data', 'profile'),
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data() as PersonalData;
          setPersonalData(data);
          localStorage.setItem(LS_PERSONAL, JSON.stringify(data));
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/personal_data/profile`);
      }
    );

    // Listen to Other Expenses
    const unsubExpenses = onSnapshot(
      collection(db, 'users', userId, 'other_expenses'),
      (snapshot) => {
        const list: OtherExpense[] = [];
        snapshot.forEach((docSnap) => {
          const exp = docSnap.data() as OtherExpense;
          // Normalize legacy entries to cash if undefined
          if (!exp.paymentStatus) {
            exp.paymentStatus = 'cash';
            exp.paidAmount = exp.amount;
            exp.dueAmount = 0;
          }
          list.push(exp);
        });
        list.sort((a, b) => b.date.localeCompare(a.date));
        setExpenses(list);
        localStorage.setItem(LS_EXPENSES, JSON.stringify(list));
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/other_expenses`);
      }
    );

    // Listen to Expense Creditors
    const unsubCreditors = onSnapshot(
      collection(db, 'users', userId, 'expense_creditors'),
      (snapshot) => {
        const list: ExpenseCreditor[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as ExpenseCreditor);
        });
        list.sort((a, b) => a.name.localeCompare(b.name));
        setExpenseCreditors(list);
        localStorage.setItem(LS_CREDITORS, JSON.stringify(list));
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/expense_creditors`);
      }
    );

    // Listen to Expense Payments
    const unsubExpPayments = onSnapshot(
      collection(db, 'users', userId, 'expense_payments'),
      (snapshot) => {
        const list: ExpensePayment[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as ExpensePayment);
        });
        list.sort((a, b) => b.date.localeCompare(a.date));
        setExpensePayments(list);
        localStorage.setItem(LS_EXP_PAYMENTS, JSON.stringify(list));
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/expense_payments`);
      }
    );

    // Listen to Personal People
    const unsubPeople = onSnapshot(
      collection(db, 'users', userId, 'personal_people'),
      (snapshot) => {
        const list: PersonalPerson[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as PersonalPerson);
        });
        list.sort((a, b) => a.name.localeCompare(b.name));
        setPersonalPeople(list);
        localStorage.setItem(LS_PEOPLE, JSON.stringify(list));
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/personal_people`);
      }
    );

    // Listen to Personal Loans
    const unsubLoans = onSnapshot(
      collection(db, 'users', userId, 'personal_loans'),
      (snapshot) => {
        const list: PersonalLoan[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as PersonalLoan);
        });
        list.sort((a, b) => b.date.localeCompare(a.date));
        setPersonalLoans(list);
        localStorage.setItem(LS_LOANS, JSON.stringify(list));
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/personal_loans`);
      }
    );

    // Listen to Personal Repayments
    const unsubRepayments = onSnapshot(
      collection(db, 'users', userId, 'personal_repayments'),
      (snapshot) => {
        const list: PersonalRepayment[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as PersonalRepayment);
        });
        list.sort((a, b) => b.date.localeCompare(a.date));
        setPersonalRepayments(list);
        localStorage.setItem(LS_REPAYMENTS, JSON.stringify(list));
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `users/${userId}/personal_repayments`);
      }
    );

    return () => {
      unsubDrivers();
      unsubEntries();
      unsubPersonal();
      unsubExpenses();
      unsubCreditors();
      unsubExpPayments();
      unsubPeople();
      unsubLoans();
      unsubRepayments();
    };
  }, [user]);

  const persistLocally = (
    newDrivers = drivers,
    newEntries = entries,
    newPersonal = personalData,
    newExpenses = expenses,
    newPeople = personalPeople,
    newLoans = personalLoans,
    newRepayments = personalRepayments,
    newCreditors = expenseCreditors,
    newExpPayments = expensePayments
  ) => {
    localStorage.setItem(LS_DRIVERS, JSON.stringify(newDrivers));
    localStorage.setItem(LS_ENTRIES, JSON.stringify(newEntries));
    localStorage.setItem(LS_PERSONAL, JSON.stringify(newPersonal));
    localStorage.setItem(LS_EXPENSES, JSON.stringify(newExpenses));
    localStorage.setItem(LS_PEOPLE, JSON.stringify(newPeople));
    localStorage.setItem(LS_LOANS, JSON.stringify(newLoans));
    localStorage.setItem(LS_REPAYMENTS, JSON.stringify(newRepayments));
    localStorage.setItem(LS_CREDITORS, JSON.stringify(newCreditors));
    localStorage.setItem(LS_EXP_PAYMENTS, JSON.stringify(newExpPayments));
  };

  // Add new Driver
  const addDriver = async (data: {
    name: string;
    vehicleCategory?: VehicleCategory;
    vehicleReg?: string;
    phone?: string;
  }): Promise<Driver> => {
    const driverId = `drv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const ownerId = user ? user.uid : 'local-owner';

    const newDriver: Driver = {
      id: driverId,
      ownerId,
      name: data.name.trim(),
      vehicleCategory: data.vehicleCategory,
      vehicleReg: data.vehicleReg?.trim().toUpperCase(),
      phone: data.phone?.trim(),
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...drivers, newDriver].sort((a, b) => a.name.localeCompare(b.name));
    setDrivers(updated);
    persistLocally(updated, entries, personalData, expenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/drivers/${driverId}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'drivers', driverId), newDriver);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    }

    return newDriver;
  };

  const updateDriver = async (id: string, updates: Partial<Driver>) => {
    const now = new Date().toISOString();
    const existing = drivers.find((d) => d.id === id);
    if (!existing) throw new Error('Driver not found');

    const updated: Driver = { ...existing, ...updates, updatedAt: now };
    const updatedList = drivers.map((d) => (d.id === id ? updated : d));
    setDrivers(updatedList);
    persistLocally(updatedList, entries, personalData, expenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/drivers/${id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'drivers', id), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    }
  };

  const deleteDriver = async (id: string) => {
    const updatedDrivers = drivers.filter((d) => d.id !== id);
    const updatedEntries = entries.filter((e) => e.driverId !== id);

    setDrivers(updatedDrivers);
    setEntries(updatedEntries);
    persistLocally(updatedDrivers, updatedEntries, personalData, expenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'drivers', id));
      } catch (err) {
        console.warn(err);
      }
    }
  };

  const getDriverEntries = (driverId: string): KantaEntry[] => {
    return entries
      .filter((e) => e.driverId === driverId)
      .sort((a, b) => {
        if (a.date === b.date) {
          return (b.createdAt || '').localeCompare(a.createdAt || '');
        }
        return b.date.localeCompare(a.date);
      });
  };

  const addDriverEntry = async (
    driverId: string,
    entry: {
      date: string;
      vehicleCategory: VehicleCategory;
      vehicleReg?: string;
      firstWeight: number | '';
      secondWeight: number | '';
      thirdWeight: number | '';
      totalPrice: number;
      receivedPrice: number;
      duePrice: number;
    }
  ): Promise<KantaEntry> => {
    const driver = drivers.find((d) => d.id === driverId);
    if (!driver) throw new Error('Driver not found for this khata.');

    const entryId = `entry_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const ownerId = user ? user.uid : 'local-owner';

    const newEntry: KantaEntry = {
      id: entryId,
      ownerId,
      driverId: driver.id,
      driverName: driver.name,
      date: entry.date,
      vehicleCategory: entry.vehicleCategory,
      vehicleReg: entry.vehicleReg?.trim().toUpperCase(),
      firstWeight: entry.firstWeight !== '' ? Number(entry.firstWeight) : '',
      secondWeight: entry.secondWeight !== '' ? Number(entry.secondWeight) : '',
      thirdWeight: entry.thirdWeight !== '' ? Number(entry.thirdWeight) : '',
      totalPrice: Number(entry.totalPrice) || 0,
      receivedPrice: Number(entry.receivedPrice) || 0,
      duePrice: Number(entry.duePrice) || 0,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [newEntry, ...entries];
    setEntries(updated);
    persistLocally(drivers, updated, personalData, expenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/kanta_entries/${entryId}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'kanta_entries', entryId), newEntry);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    }

    return newEntry;
  };

  const updateEntry = async (entryId: string, updates: Partial<KantaEntry>) => {
    const now = new Date().toISOString();
    const existing = entries.find((e) => e.id === entryId);
    if (!existing) throw new Error('Entry not found');

    const updated: KantaEntry = { ...existing, ...updates, updatedAt: now };
    const updatedList = entries.map((e) => (e.id === entryId ? updated : e));
    setEntries(updatedList);
    persistLocally(drivers, updatedList, personalData, expenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/kanta_entries/${entryId}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'kanta_entries', entryId), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    }
  };

  const deleteEntry = async (entryId: string) => {
    const updatedList = entries.filter((e) => e.id !== entryId);
    setEntries(updatedList);
    persistLocally(drivers, updatedList, personalData, expenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/kanta_entries/${entryId}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'kanta_entries', entryId));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    }
  };

  const updatePersonalData = async (data: Partial<PersonalData>) => {
    const now = new Date().toISOString();
    const merged = { ...personalData, ...data, updatedAt: now };
    setPersonalData(merged);
    persistLocally(drivers, entries, merged, expenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/personal_data/profile`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'personal_data', 'profile'), merged);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    }
  };

  // ==========================================
  // Other Expenses — Cash or Credit (Udhar)
  // ==========================================

  const addExpense = async (expense: {
    date: string;
    category: string;
    description?: string;
    amount: number;
    paymentStatus: ExpensePaymentStatus;
    creditorId?: string;
    creditorName?: string;
    initialPaid?: number;
    paymentMethod?: string;
  }): Promise<OtherExpense> => {
    const id = `exp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const ownerId = user ? user.uid : 'local-owner';
    const totalAmount = Number(expense.amount) || 0;

    const isCredit = expense.paymentStatus === 'credit';
    const paidAmount = isCredit ? Math.min(totalAmount, Number(expense.initialPaid) || 0) : totalAmount;
    const dueAmount = Math.max(0, totalAmount - paidAmount);

    const newExp: OtherExpense = {
      id,
      ownerId,
      date: expense.date,
      category: expense.category,
      description: expense.description?.trim() || undefined,
      amount: totalAmount,
      paymentStatus: expense.paymentStatus,
      creditorId: isCredit ? expense.creditorId : undefined,
      creditorName: isCredit ? expense.creditorName : undefined,
      paidAmount,
      dueAmount,
      paymentMethod: expense.paymentMethod || 'Cash',
      createdAt: now,
      updatedAt: now,
    };

    const updated = [newExp, ...expenses];
    setExpenses(updated);
    persistLocally(drivers, entries, personalData, updated, personalPeople, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/other_expenses/${id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'other_expenses', id), newExp);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    }

    // If credit with initial partial payment, save payment entry
    if (isCredit && paidAmount > 0 && expense.creditorId) {
      await addExpensePayment({
        expenseId: id,
        creditorId: expense.creditorId,
        date: expense.date,
        amount: paidAmount,
        notes: 'Initial payment upon credit purchase',
      });
    }

    return newExp;
  };

  const deleteExpense = async (id: string) => {
    const updated = expenses.filter((e) => e.id !== id);
    const updatedPayments = expensePayments.filter((p) => p.expenseId !== id);

    setExpenses(updated);
    setExpensePayments(updatedPayments);
    persistLocally(drivers, entries, personalData, updated, personalPeople, personalLoans, personalRepayments, expenseCreditors, updatedPayments);

    if (user) {
      const path = `users/${user.uid}/other_expenses/${id}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'other_expenses', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    }
  };

  // Add Expense Creditor
  const addExpenseCreditor = async (data: {
    name: string;
    phone?: string;
    notes?: string;
  }): Promise<ExpenseCreditor> => {
    const id = `crd_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const ownerId = user ? user.uid : 'local-owner';

    const newCreditor: ExpenseCreditor = {
      id,
      ownerId,
      name: data.name.trim(),
      phone: data.phone?.trim() || undefined,
      notes: data.notes?.trim() || undefined,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...expenseCreditors, newCreditor].sort((a, b) => a.name.localeCompare(b.name));
    setExpenseCreditors(updated);
    persistLocally(drivers, entries, personalData, expenses, personalPeople, personalLoans, personalRepayments, updated, expensePayments);

    if (user) {
      const path = `users/${user.uid}/expense_creditors/${id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'expense_creditors', id), newCreditor);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    }
    return newCreditor;
  };

  const updateExpenseCreditor = async (id: string, updates: Partial<ExpenseCreditor>) => {
    const now = new Date().toISOString();
    const existing = expenseCreditors.find((c) => c.id === id);
    if (!existing) throw new Error('Creditor not found');

    const updated: ExpenseCreditor = { ...existing, ...updates, updatedAt: now };
    const updatedList = expenseCreditors.map((c) => (c.id === id ? updated : c));
    setExpenseCreditors(updatedList);
    persistLocally(drivers, entries, personalData, expenses, personalPeople, personalLoans, personalRepayments, updatedList, expensePayments);

    if (user) {
      const path = `users/${user.uid}/expense_creditors/${id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'expense_creditors', id), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    }
  };

  const deleteExpenseCreditor = async (id: string) => {
    const updatedCreditors = expenseCreditors.filter((c) => c.id !== id);
    setExpenseCreditors(updatedCreditors);
    persistLocally(drivers, entries, personalData, expenses, personalPeople, personalLoans, personalRepayments, updatedCreditors, expensePayments);

    if (user) {
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'expense_creditors', id));
      } catch (err) {
        console.warn(err);
      }
    }
  };

  // Add Payment towards a Credit Expense
  const addExpensePayment = async (data: {
    expenseId: string;
    creditorId: string;
    date: string;
    amount: number;
    notes?: string;
  }): Promise<ExpensePayment> => {
    const paymentId = `exp_pay_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const ownerId = user ? user.uid : 'local-owner';
    const numAmount = Number(data.amount) || 0;

    const newPayment: ExpensePayment = {
      id: paymentId,
      ownerId,
      expenseId: data.expenseId,
      creditorId: data.creditorId,
      date: data.date,
      amount: numAmount,
      notes: data.notes?.trim() || undefined,
      createdAt: now,
    };

    const updatedPayments = [newPayment, ...expensePayments];
    setExpensePayments(updatedPayments);

    // Update expense paidAmount and dueAmount
    const exp = expenses.find((e) => e.id === data.expenseId);
    let updatedExpenses = expenses;
    if (exp) {
      const newPaid = (exp.paidAmount || 0) + numAmount;
      const newDue = Math.max(0, exp.amount - newPaid);
      const updatedExp: OtherExpense = {
        ...exp,
        paidAmount: newPaid,
        dueAmount: newDue,
        updatedAt: now,
      };
      updatedExpenses = expenses.map((e) => (e.id === exp.id ? updatedExp : e));
      setExpenses(updatedExpenses);

      if (user) {
        try {
          await setDoc(doc(db, 'users', user.uid, 'other_expenses', exp.id), updatedExp);
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}/other_expenses/${exp.id}`);
        }
      }
    }

    persistLocally(drivers, entries, personalData, updatedExpenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, updatedPayments);

    if (user) {
      const path = `users/${user.uid}/expense_payments/${paymentId}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'expense_payments', paymentId), newPayment);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    }

    return newPayment;
  };

  const deleteExpensePayment = async (id: string) => {
    const payment = expensePayments.find((p) => p.id === id);
    if (!payment) return;

    const updatedPayments = expensePayments.filter((p) => p.id !== id);
    setExpensePayments(updatedPayments);

    // Revert amount on parent expense
    const exp = expenses.find((e) => e.id === payment.expenseId);
    let updatedExpenses = expenses;
    if (exp) {
      const newPaid = Math.max(0, (exp.paidAmount || 0) - payment.amount);
      const newDue = Math.max(0, exp.amount - newPaid);
      const updatedExp: OtherExpense = {
        ...exp,
        paidAmount: newPaid,
        dueAmount: newDue,
        updatedAt: new Date().toISOString(),
      };
      updatedExpenses = expenses.map((e) => (e.id === exp.id ? updatedExp : e));
      setExpenses(updatedExpenses);

      if (user) {
        try {
          await setDoc(doc(db, 'users', user.uid, 'other_expenses', exp.id), updatedExp);
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}/other_expenses/${exp.id}`);
        }
      }
    }

    persistLocally(drivers, entries, personalData, updatedExpenses, personalPeople, personalLoans, personalRepayments, expenseCreditors, updatedPayments);

    if (user) {
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'expense_payments', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `users/${user.uid}/expense_payments/${id}`);
      }
    }
  };

  const getCreditorExpenses = (creditorId: string): OtherExpense[] => {
    return expenses
      .filter((e) => e.creditorId === creditorId)
      .sort((a, b) => b.date.localeCompare(a.date));
  };

  const getCreditorPayments = (creditorId: string): ExpensePayment[] => {
    return expensePayments
      .filter((p) => p.creditorId === creditorId)
      .sort((a, b) => b.date.localeCompare(a.date));
  };

  const getExpensePayments = (expenseId: string): ExpensePayment[] => {
    return expensePayments
      .filter((p) => p.expenseId === expenseId)
      .sort((a, b) => b.date.localeCompare(a.date));
  };

  const getCreditorBalances = (creditorId: string): CreditorBalanceSummary => {
    const credExpenses = expenses.filter((e) => e.creditorId === creditorId);
    const totalCredit = credExpenses.reduce((sum, e) => sum + e.amount, 0);
    const totalPaid = credExpenses.reduce((sum, e) => sum + (e.paidAmount || 0), 0);
    const remainingDue = Math.max(0, totalCredit - totalPaid);

    return {
      totalCredit,
      totalPaid,
      remainingDue,
    };
  };

  // ==========================================
  // Personal Data — Loan & Udhar Accounts
  // ==========================================

  const addPersonalPerson = async (data: {
    name: string;
    phone?: string;
    notes?: string;
  }): Promise<PersonalPerson> => {
    const personId = `prs_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const ownerId = user ? user.uid : 'local-owner';

    const newPerson: PersonalPerson = {
      id: personId,
      ownerId,
      name: data.name.trim(),
      phone: data.phone?.trim() || undefined,
      notes: data.notes?.trim() || undefined,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [...personalPeople, newPerson].sort((a, b) => a.name.localeCompare(b.name));
    setPersonalPeople(updated);
    persistLocally(drivers, entries, personalData, expenses, updated, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/personal_people/${personId}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'personal_people', personId), newPerson);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    }
    return newPerson;
  };

  const updatePersonalPerson = async (id: string, updates: Partial<PersonalPerson>) => {
    const now = new Date().toISOString();
    const existing = personalPeople.find((p) => p.id === id);
    if (!existing) throw new Error('Person not found');

    const updated: PersonalPerson = { ...existing, ...updates, updatedAt: now };
    const updatedList = personalPeople.map((p) => (p.id === id ? updated : p));
    setPersonalPeople(updatedList);
    persistLocally(drivers, entries, personalData, expenses, updatedList, personalLoans, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/personal_people/${id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'personal_people', id), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    }
  };

  const deletePersonalPerson = async (id: string) => {
    const updatedPeople = personalPeople.filter((p) => p.id !== id);
    const updatedLoans = personalLoans.filter((l) => l.personId !== id);
    const updatedRepayments = personalRepayments.filter((r) => r.personId !== id);

    setPersonalPeople(updatedPeople);
    setPersonalLoans(updatedLoans);
    setPersonalRepayments(updatedRepayments);
    persistLocally(drivers, entries, personalData, expenses, updatedPeople, updatedLoans, updatedRepayments, expenseCreditors, expensePayments);

    if (user) {
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'personal_people', id));
      } catch (err) {
        console.warn(err);
      }
    }
  };

  const addPersonalLoan = async (data: {
    personId: string;
    personName: string;
    date: string;
    type: LoanType;
    amount: number;
    notes?: string;
  }): Promise<PersonalLoan> => {
    const loanId = `loan_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const ownerId = user ? user.uid : 'local-owner';

    const newLoan: PersonalLoan = {
      id: loanId,
      ownerId,
      personId: data.personId,
      personName: data.personName,
      date: data.date,
      type: data.type,
      amount: Number(data.amount) || 0,
      notes: data.notes?.trim() || undefined,
      createdAt: now,
      updatedAt: now,
    };

    const updated = [newLoan, ...personalLoans];
    setPersonalLoans(updated);
    persistLocally(drivers, entries, personalData, expenses, personalPeople, updated, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/personal_loans/${loanId}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'personal_loans', loanId), newLoan);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    }
    return newLoan;
  };

  const updatePersonalLoan = async (id: string, updates: Partial<PersonalLoan>) => {
    const now = new Date().toISOString();
    const existing = personalLoans.find((l) => l.id === id);
    if (!existing) throw new Error('Loan record not found');

    const updated: PersonalLoan = { ...existing, ...updates, updatedAt: now };
    const updatedList = personalLoans.map((l) => (l.id === id ? updated : l));
    setPersonalLoans(updatedList);
    persistLocally(drivers, entries, personalData, expenses, personalPeople, updatedList, personalRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/personal_loans/${id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'personal_loans', id), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    }
  };

  const deletePersonalLoan = async (id: string) => {
    const updatedLoans = personalLoans.filter((l) => l.id !== id);
    const updatedRepayments = personalRepayments.filter((r) => r.loanId !== id);

    setPersonalLoans(updatedLoans);
    setPersonalRepayments(updatedRepayments);
    persistLocally(drivers, entries, personalData, expenses, personalPeople, updatedLoans, updatedRepayments, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/personal_loans/${id}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'personal_loans', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    }
  };

  const addPersonalRepayment = async (data: {
    personId: string;
    loanId: string;
    date: string;
    direction: RepaymentDirection;
    amount: number;
    notes?: string;
  }): Promise<PersonalRepayment> => {
    const id = `repay_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const ownerId = user ? user.uid : 'local-owner';

    const newRepayment: PersonalRepayment = {
      id,
      ownerId,
      personId: data.personId,
      loanId: data.loanId,
      date: data.date,
      direction: data.direction,
      amount: Number(data.amount) || 0,
      notes: data.notes?.trim() || undefined,
      createdAt: now,
    };

    const updated = [newRepayment, ...personalRepayments];
    setPersonalRepayments(updated);
    persistLocally(drivers, entries, personalData, expenses, personalPeople, personalLoans, updated, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/personal_repayments/${id}`;
      try {
        await setDoc(doc(db, 'users', user.uid, 'personal_repayments', id), newRepayment);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    }
    return newRepayment;
  };

  const deletePersonalRepayment = async (id: string) => {
    const updated = personalRepayments.filter((r) => r.id !== id);
    setPersonalRepayments(updated);
    persistLocally(drivers, entries, personalData, expenses, personalPeople, personalLoans, updated, expenseCreditors, expensePayments);

    if (user) {
      const path = `users/${user.uid}/personal_repayments/${id}`;
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'personal_repayments', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    }
  };

  const getPersonLoans = (personId: string): PersonalLoan[] => {
    return personalLoans
      .filter((l) => l.personId === personId)
      .sort((a, b) => {
        if (a.date === b.date) {
          return (b.createdAt || '').localeCompare(a.createdAt || '');
        }
        return b.date.localeCompare(a.date);
      });
  };

  const getPersonRepayments = (personId: string): PersonalRepayment[] => {
    return personalRepayments
      .filter((r) => r.personId === personId)
      .sort((a, b) => {
        if (a.date === b.date) {
          return (b.createdAt || '').localeCompare(a.createdAt || '');
        }
        return b.date.localeCompare(a.date);
      });
  };

  const getLoanRepayments = (loanId: string): PersonalRepayment[] => {
    return personalRepayments
      .filter((r) => r.loanId === loanId)
      .sort((a, b) => b.date.localeCompare(a.date));
  };

  const getLoanRemaining = (loanId: string): number => {
    const loan = personalLoans.find((l) => l.id === loanId);
    if (!loan) return 0;
    const repayments = personalRepayments.filter((r) => r.loanId === loanId);
    const totalRepaid = repayments.reduce((sum, r) => sum + r.amount, 0);
    return Math.max(0, loan.amount - totalRepaid);
  };

  const getPersonBalances = (personId: string): PersonBalanceSummary => {
    const pLoans = personalLoans.filter((l) => l.personId === personId);
    const pRepayments = personalRepayments.filter((r) => r.personId === personId);

    const totalBorrowed = pLoans
      .filter((l) => l.type === 'borrowed')
      .reduce((sum, l) => sum + l.amount, 0);

    const totalRepaidBorrowed = pRepayments
      .filter((r) => r.direction === 'repaid_borrowed')
      .reduce((sum, r) => sum + r.amount, 0);

    const remainingBorrowed = Math.max(0, totalBorrowed - totalRepaidBorrowed);

    const totalLent = pLoans
      .filter((l) => l.type === 'lent')
      .reduce((sum, l) => sum + l.amount, 0);

    const totalRepaidLent = pRepayments
      .filter((r) => r.direction === 'received_lent')
      .reduce((sum, r) => sum + r.amount, 0);

    const remainingLent = Math.max(0, totalLent - totalRepaidLent);
    const netPosition = remainingLent - remainingBorrowed;

    return {
      totalBorrowed,
      totalRepaidBorrowed,
      remainingBorrowed,
      totalLent,
      totalRepaidLent,
      remainingLent,
      netPosition,
    };
  };

  return (
    <KantaDataContext.Provider
      value={{
        drivers,
        entries,
        personalData,
        expenses,
        personalPeople,
        personalLoans,
        personalRepayments,
        expenseCreditors,
        expensePayments,
        loading,
        addDriver,
        updateDriver,
        deleteDriver,
        getDriverEntries,
        addDriverEntry,
        updateEntry,
        deleteEntry,
        updatePersonalData,
        addExpense,
        deleteExpense,
        addExpenseCreditor,
        updateExpenseCreditor,
        deleteExpenseCreditor,
        addExpensePayment,
        deleteExpensePayment,
        getCreditorExpenses,
        getCreditorPayments,
        getExpensePayments,
        getCreditorBalances,
        addPersonalPerson,
        updatePersonalPerson,
        deletePersonalPerson,
        addPersonalLoan,
        updatePersonalLoan,
        deletePersonalLoan,
        addPersonalRepayment,
        deletePersonalRepayment,
        getPersonLoans,
        getPersonRepayments,
        getLoanRepayments,
        getPersonBalances,
        getLoanRemaining,
      }}
    >
      {children}
    </KantaDataContext.Provider>
  );
};

export const useKantaData = () => {
  const context = useContext(KantaDataContext);
  if (!context) {
    throw new Error('useKantaData must be used within a KantaDataProvider');
  }
  return context;
};
